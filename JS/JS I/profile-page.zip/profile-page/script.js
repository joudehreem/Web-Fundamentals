/*
Developer:Reem Joudeh
Email:Reem Joudeh
Description: Assignment of Making Connections,This script assigns functionality interact with elements using three functionsUpdate the name of the user profile, Remove elements from a request list and decrement a counter, and Add elements to a request list and increment a counter

Input:Three functions responsible for interacting with the page and performing actions. 
Output:Changing the name of the user profile,removing elements from a request list and updating counts accordingly when interacting with add and close buttons.. 
*/

console.log("page loaded...");

/*
Desc: This function will do ...
Developer Name: 
Time:
Email:
Input: 
Outputs:
*/
function editName(elementId) {
  document.getElementById(elementId).innerHTML = "Reem Joudeh";
}

var count = document.querySelectorAll(".badge");

function remove(elementId) {
  document.getElementById(elementId).remove();

  count[0].innerHTML -= 1;
}
var list = document.getElementsByClassName("card-list")[1];

function add(elementId, userId) {
  var count2 = count[1].innerHTML;
  count[1].innerHTML = parseInt(count2) + 1;
  var element = document.getElementById(userId);

  list.appendChild(element);
  remove(elementId);
}
