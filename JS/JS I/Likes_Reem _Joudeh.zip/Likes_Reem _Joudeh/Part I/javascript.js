

var addLike = document.querySelector('.h1')

var count = 3;

function countLike(element) {
  count++;
  addLike.textContent = `Like ${count}`
}